const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/user'); // Middleware d'authentification
const { getUsersList } = require('../controllers/users'); // Contrôleur pour la liste des utilisateurs

// Route pour récupérer la liste des utilisateurs
router.route("")
    .get( protect, getUsersList);

module.exports = router;
