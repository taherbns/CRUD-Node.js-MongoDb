const express = require('express');
const router = express.Router();


const { getFriendsPositions, UpdatePosition } = require('../controllers/position');
const { protect } = require('../middleware/user');

router.route('/friends')
    .get(protect, getFriendsPositions);

router.route('/')
    .put(protect, UpdatePosition);

module.exports = router;