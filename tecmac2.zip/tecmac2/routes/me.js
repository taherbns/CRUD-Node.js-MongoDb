const express = require('express');
const router = express.Router();
const { protect } = require('../middleware/user'); // Middleware d'authentification
const { getCurrentUser, updateCurrentUser, deleteCurrentUser } = require('../controllers/me'); // Contrôleurs pour les actions de l'utilisateur actuel

// Route pour obtenir les informations de l'utilisateur actuel
router.route('')
.get( protect, getCurrentUser);

// Route pour modifier les informations de l'utilisateur actuel
router.route('')
.post( protect, updateCurrentUser);
// Route pour supprimer l'utilisateur actuel
router.route('')
.delete( protect, deleteCurrentUser);

module.exports = router;
