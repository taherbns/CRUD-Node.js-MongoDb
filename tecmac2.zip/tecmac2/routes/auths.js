// Importation du module Express
const express = require('express'); // Importation du framework Express
const router = express.Router(); // Création d'un routeur Express

// Importation des contrôleurs pour l'authentification
const authController = require('../controllers/auth'); // Importation des fonctions de contrôleur pour l'authentification

// Configuration des routes
router.route('/register')
    .post(authController.register); // Définition d'une route de type POST avec le contrôleur "register" pour l'inscription d'un utilisateur

router.route('/login')
    .post(authController.login); // Définition d'une route de type POST avec le contrôleur "login" pour la connexion d'un utilisateur

module.exports = router; // Exportation du routeur pour une utilisation ultérieure
