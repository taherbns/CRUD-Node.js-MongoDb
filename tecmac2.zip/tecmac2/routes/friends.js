const express = require('express');
const router = express.Router();
const { getFriendsList , addFriend , deleteFriend }  = require('../controllers/friends');
const { protect } = require('../middleware/user');

router.route('')
    .get(protect, getFriendsList);

router.route('/:userId')
    .post(protect, addFriend);

    router.route('/:userId')
    .delete(protect, deleteFriend);
module.exports = router;
