// Importation des modules nécessaires
const express = require('express'); // Framework pour les applications web Node.js
const mongoose = require('mongoose'); // ODM (Object Data Modeling) pour MongoDB


// Importation des routes
 const routesAuth = require('./routes/auths'); // Routes pour l'authentification
 const routesPosition = require('./routes/position'); // Routes pour les positions
 const routesFriends = require('./routes/friends'); // Routes pour les amis
 const routesUsers = require('./routes/users'); // Routes pour les utilisateurs
const routesMe = require('./routes/me'); // Routes pour le profil de l'utilisateur connecté



// Initialisation de l'application Express
const app = express(); // Création de l'application Express


// Middleware pour traiter les requêtes au format JSON
app.use(express.json());
const PORT = 5000;
// Configuration des routes
 app.use('/auth', routesAuth); // Utilisation des routes d'authentification
 app.use('/position', routesPosition); // Utilisation des routes de position
 app.use('/friends', routesFriends); // Utilisation des routes d'amis
 app.use('/users', routesUsers); // Utilisation des routes d'utilisateurs
 app.use('/me', routesMe); // Utilisation des routes pour le profil de l'utilisateur connecté

// Démarrage du serveur
app.listen(PORT, () => {
    console.log(`Server is listening on port : ${PORT}`); // Affichage du message de démarrage du serveur
});

// Connexion à la base de données MongoDB
const connectDb = async () => {
    try {
        const conn = await mongoose.connect('mongodb+srv://taherbns:taherbns@cluster0.vgralqn.mongodb.net/'); // Connexion à MongoDB
        console.log(`connected to mongoDb : ${conn.connection.host}`); // Affichage du message de connexion réussie
    } catch (error) {
        console.log(`error : ${error}`); // Affichage d'un message d'erreur en cas de problème de connexion
    }
}
connectDb(); // Appel de la fonction de connexion à la base de données
