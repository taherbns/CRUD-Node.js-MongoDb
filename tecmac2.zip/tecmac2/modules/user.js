const mongoose = require('mongoose');

// Définition du schéma de modèle pour l'utilisateur
const UserSchema = new mongoose.Schema({
    id: {
        type: Number,
        // Auto-increment should typically be managed by the database, not defined here
    },
    email: {
        type: String,
        required: [true, 'Please enter an email'],
        unique: [true,'Email already exists']
    },
    password: {
        type: String,
        required: [true, 'Please enter a password']
    },
    username: {
        type: String,
        required: [true, 'Please enter a username']
    },
    fullname: {
        type: String,
        required: [true, 'Please enter a fullname']
    },
    long: {
        type: Number
    },
    lat: {
        type: Number
    },
    friend: [{
        type: mongoose.Schema.Types.ObjectId, // Use mongoose.Schema.Types.ObjectId instead of mongoose.Schema.ObjectId
        ref: 'User' // Reference the 'User' model for the friend relationship
    }],
});

// Création du modèle 'User' à partir du schéma
module.exports = mongoose.model('User', UserSchema);
