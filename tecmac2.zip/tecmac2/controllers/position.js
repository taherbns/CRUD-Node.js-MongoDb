const User = require('../modules/user');

exports.getFriendsPositions = async (req, res) => {
    try {
        // Récupération de l'ID de l'utilisateur authentifié depuis le token
        const userId = req.userId;

        // Récupération de l'utilisateur et de ses amis avec leurs positions
        const user = await User.findById(userId).populate('friend', 'lat long -_id');

        // Extraction des positions des amis
        const friendsPositions = user.friend.map(friend => ({
            userId: friend._id,
            lat: friend.lat,
            long: friend.long
        }));

        return res.status(200).json(friendsPositions);
    } catch (error) {
        return res.status(500).json({ 'success': false, 'msg': 'Erreur lors de la récupération des positions des amis.' });
    }
};

exports.UpdatePosition = async (req, res) => {
    try {
        const { lat, long } = req.body;
        const userId = req.userId; // Récupérer l'ID de l'utilisateur à partir du token d'authentification

        // Vérification des coordonnées passées dans le corps de la requête
        if (!lat || !long) {
            return res.status(400).json({ success: false, msg: 'Coordonnées de position manquantes.' });
        }

        // Mise à jour de la position de l'utilisateur dans la base de données
        await User.findByIdAndUpdate(userId, { lat: lat, long: long });

        return res.status(200).json({ success: true, msg: 'Position mise à jour avec succès.' });
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la mise à jour de la position.' });
    }
};