const User = require('../modules/user');

// Obtenir les informations de l'utilisateur actuel
exports.getCurrentUser = async (req, res) => {
    try {
        const user = await User.findById(req.userId, 'username email'); // Récupérer uniquement les champs username et email
        return res.status(200).json(user);
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la récupération des informations de l\'utilisateur.' });
    }
};

// Modifier les informations de l'utilisateur actuel
exports.updateCurrentUser = async (req, res) => {
    try {
        const { username, email } = req.body; // Récupérer les nouvelles informations
        const user = await User.findById(req.userId); // Récupérer l'utilisateur

        // Vérifier si l'email est déjà utilisé par un autre utilisateur
        const existingUser = await User.findOne({ email });
        if (existingUser && existingUser._id.toString() !== req.userId) {
            return res.status(409).json({ success: false, msg: 'Cette adresse e-mail est déjà utilisée par un autre utilisateur.' });
        }

        // Mettre à jour les informations de l'utilisateur
        if (username) user.username = username;
        if (email) user.email = email;

        await user.save();
        return res.status(200).json({ success: true, msg: 'Informations de l\'utilisateur mises à jour.' });
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la modification des informations de l\'utilisateur.' });
    }
};

// Supprimer l'utilisateur actuel
exports.deleteCurrentUser = async (req, res) => {
    try {
        await User.findByIdAndDelete(req.userId); // Supprimer l'utilisateur
        return res.status(204).send(); // Renvoyer une réponse vide pour indiquer le succès
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la suppression de l\'utilisateur.' });
    }
};
