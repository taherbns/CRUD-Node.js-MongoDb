const jwt = require('jsonwebtoken');
const User = require('../modules/user'); // Importation du modèle User

// Contrôleur pour la connexion d'un utilisateur
exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        if (!email || !password) {
            return res.status(400).send({ 'success': false, 'msg': 'Paramètres manquants ou invalides' });
        }

        const user = await User.findOne({ 'email': email });

        if (!user || user.password !== password) {
            return res.status(401).send({ 'success': false, 'msg': 'Adresse e-mail ou mot de passe incorrect' });
        }

        const token = jwt.sign({ 'id': user._id }, 'tecmac2');
        return res.status(200).send({ 'success': true, 'token': token });
    } catch (error) {
        return res.status(400).send({ 'success': false, 'msg': 'Informations invalides' });
    }
}



// Contrôleur pour l'inscription d'un nouvel utilisateur
exports.register = async (req, res) => {
    try {
        const { email, password, username, fullname } = req.body;

        // Vérification si l'email existe déjà dans la base de données
        const existingUser = await User.findOne({ email });

        if (existingUser) {
            return res.status(409).send({ 'success': false, 'msg': 'Adresse e-mail déjà utilisée' });
        }

        // Vérification des paramètres manquants
        if (!email || !password || !username || !fullname) {
            return res.status(400).send({ 'success': false, 'msg': 'Paramètres manquants ou invalides' });
        }
        // on crée un nouvel utilisateur
        const newUser = await User.create({ email, password, username, fullname });

        // Generer le token 
        const token = jwt.sign({ id: newUser.id }, 'tecmac2');

        return res.status(201).send({ 'success': true , 'msg': 'Utilisateur créé avec succès', 'token': token });
        
    } catch (error) {
        return res.status(500).send({ 'success': false, 'msg': 'Une erreur s\'est produite lors de l\'inscription de l\'utilisateur.' });
    }
}
