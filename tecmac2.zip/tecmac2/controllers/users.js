const User = require('../modules/user');

exports.getUsersList = async (req, res) => {
    try {
        const users = await User.find({}, 'id username fullName'); // Récupérer uniquement les champs id, username et fullName
        return res.status(200).json(users);
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la récupération des utilisateurs.' });
    }
};
