const User = require('../modules/user');

exports.getFriendsList = async (req, res) => {
    try {
        const userId = req.userId; // ID de l'utilisateur authentifié

        // Récupération de l'utilisateur et de sa liste d'amis
        const user = await User.findById(userId).populate('friend', 'userId username -_id');

        // Extraction de la liste d'amis avec les données requises
        const friendsList = user.friend.map(friend => ({
            userId: friend.userId,
            username: friend.username
        }));

        return res.status(200).json(friendsList);
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la récupération de la liste d\'amis.' });
    }
};

exports.addFriend = async (req, res) => {
    try {
        const userId = req.userId; // ID de l'utilisateur authentifié
        const friendId = req.params.userId; // ID de l'ami à ajouter

        // Vérification si l'ami est déjà dans la liste
        const user = await User.findById(userId);
        if (user.friend.includes(friendId)) {
            return res.status(409).json({ success: false, msg: 'L\'ami est déjà présent dans la liste.' });
        }

        // Vérification si l'utilisateur essaie de s'ajouter lui-même
        if (userId === friendId) {
            return res.status(409).json({ success: false, msg: 'Vous ne pouvez pas vous ajouter vous-même.' });
        }

        // Ajout de l'ami à la liste
        user.friend.push(friendId);
        await user.save();

        return res.status(200).json({ success: true, msg: 'Ami ajouté.' });
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de l\'ajout de l\'ami.' });
    }
};
exports.deleteFriend = async (req, res) => {
    try {
        const userId = req.userId; // ID de l'utilisateur authentifié
        const friendId = req.params.userId; // ID de l'ami à supprimer

        // Recherche de l'utilisateur et vérification si l'ami est présent dans sa liste
        const user = await User.findById(userId);
        if (!user.friend.includes(friendId)) {
            return res.status(409).json({ success: false, msg: 'Cet utilisateur n’est pas dans votre liste d’amis.' });
        }

        // Vérification si l'utilisateur essaie de se supprimer lui-même
        if (userId === friendId) {
            return res.status(409).json({ success: false, msg: 'Vous ne pouvez pas vous retirer vous-même.' });
        }

        // Suppression de l'ami de la liste
        user.friend.pull(friendId);
        await user.save();

        return res.status(200).json({ success: true, msg: 'Ami supprimé.' });
    } catch (error) {
        return res.status(500).json({ success: false, msg: 'Erreur lors de la suppression de l\'ami.' });
    }
};
